Сюда добавляйте свои фотографии.

Сейчас вместо фото используются розовые placeholder-блоки (см. .photo::before в style.css).

Чтобы заменить их на реальные фото:
1. Положите файлы сюда, например: photo1.jpg, photo2.jpg, photo3.jpg, photo4.jpg
2. В style.css найдите блок ".photo::before" и для каждого класса (.ph-1, .ph-2, .ph-3, .ph-4)
   добавьте отдельное правило, например:

   .ph-1::before{
     background-image: url('images/photo1.jpg');
     background-size: cover;
     background-position: center;
   }

3. В index.html можно убрать <span class="ph-label">...</span> внутри каждой фотографии.
